@blaze

{!! app('flux')->phoneScripts() !!}
